package Inventario.app.Model;

import android.app.Activity;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import Inventario.app.View.MainActivity;
import Inventario.app.ViewModel.usuario;

public class Fire {
    private static FirebaseDatabase db;
    private static  DatabaseReference dr;
    private static  FirebaseAuth auth;
    private  static FirebaseUser user;
    private static FirebaseStorage storage;

    public static FirebaseDatabase getDb() {
        return db;
    }

    public static DatabaseReference getDr() {
        return dr;
    }

    public static FirebaseUser getUser() {
        return user;
    }

    public static FirebaseStorage getStorage() {
        return storage;
    }

    public static FirebaseAuth getAuth(){
        return auth;
    }

    public static void conectar(Activity activity){
        FirebaseApp.initializeApp(activity);
        db= FirebaseDatabase.getInstance();
        dr=db.getReference();
        auth = FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        storage=FirebaseStorage.getInstance();
    }
    public static void login(Activity act, usuario u){
        auth.signInWithEmailAndPassword(u.getUid(),u.getContraseña())
                .addOnCompleteListener(act, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                        } else {
                            Toast.makeText(act, "No se pudo iniciar",Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
    public  static void registrar(Activity act, usuario u){
        auth.createUserWithEmailAndPassword(u.getUid(),u.getContraseña())
                .addOnCompleteListener(act, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(act,"Usuario creado con exito",Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(act, "Hubo un error, intentalo de nuevo",Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

}
