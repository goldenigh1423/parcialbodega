package Inventario.app.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import Inventario.app.Model.ConectServer;
import Inventario.app.Model.Fire;
import Inventario.app.R;

public class MainActivityMenu extends AppCompatActivity {
    Button boton1,boton2,boton3,boton4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        Fire.conectar(this);

        boton1=findViewById(R.id.Menufactura);
        boton2=findViewById(R.id.Menuinventario);
        boton3=findViewById(R.id.Menuopciones);
        boton4=findViewById(R.id.LogOut);
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fire.getAuth().signOut();
                ConectServer webSocketClient = ConectServer.getInstance();
                webSocketClient.close();
                ConectServer.borrar();
                webSocketClient=null;
                Intent intent=new Intent(MainActivityMenu.this,MainActivity.class);
                startActivity(intent);
            }
        });
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this, Facturacion.class);
                startActivity(intent);
            }
        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,InterfazInventario.class);
                startActivity(intent);
            }
        });
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityMenu.this,Opciones.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }
}