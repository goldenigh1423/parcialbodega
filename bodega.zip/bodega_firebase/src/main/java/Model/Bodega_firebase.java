package Model;
import ModelView.Producto;
import ModelView.Usuario;
import View.Login;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class Bodega_firebase {
    public static void main(String[] args) throws IOException, InterruptedException, ExecutionException{
        conect.conectar();
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("users").child("prueba");
        Usuario user=new Usuario("prueba", "prueba", "Prueba");
        user.putInventario(new Producto(506, 0, 0, "prueba", "prueba"));
        Editor.SetObj(ref,user);
        if(Editor.ingresar(ref, user).get()){
            
        }
        Login log=new Login(false);
        log.setLocationRelativeTo(null);
        log.setTitle("Bodega");
        log.setVisible(true);
    }
}
