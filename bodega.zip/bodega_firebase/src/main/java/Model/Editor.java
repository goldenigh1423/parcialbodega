package Model;

import ModelView.Producto;
import ModelView.Usuario;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Editor {
    public static CompletableFuture<Boolean> exist(DatabaseReference ref){
        CompletableFuture<Boolean> retorno=new CompletableFuture<>();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                retorno.complete(ds.exists());
            }

            @Override
            public void onCancelled(DatabaseError de) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
        return retorno;
    }
    
    public static CompletableFuture<Boolean> ingresar (DatabaseReference ref,Usuario obj){
        CompletableFuture<Boolean> retorno=new CompletableFuture<>();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                retorno.complete(obj.getContraseña().equals(ds.child("contraseña").getValue(String.class)));
                try {
                    if(retorno.get()){
                        HashMap<String,Producto> pb=new HashMap<>();
                        for(DataSnapshot muestra:ds.child("inventario").getChildren()){
                            Producto p=new Producto(muestra.child("precio").getValue(Integer.class),muestra.child("costo").getValue(Integer.class) , muestra.child("cantidad").getValue(Integer.class), muestra.child("nombre").getValue(String.class), muestra.child("id").getValue(String.class));
                            pb.put(muestra.getKey(), p);
                        }
                        obj.setInventario(pb);
                    }
                } catch (InterruptedException | ExecutionException ex) {
                }
            }

            @Override
            public void onCancelled(DatabaseError de) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
        return retorno;
    }
    
    public static void SetObj(DatabaseReference ref, Object obj){
        ref.setValueAsync(obj);
    }
    
    public static void eliminar(DatabaseReference ref){
        ref.removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError de, DatabaseReference dr) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
    }
}
