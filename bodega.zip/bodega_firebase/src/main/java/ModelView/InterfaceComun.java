package ModelView;

import javax.swing.JFrame;

interface InterfaceComun<T> {
    public abstract void registrar(T obj);
    public abstract void ingresar(T obj,JFrame ventana);
    
}
