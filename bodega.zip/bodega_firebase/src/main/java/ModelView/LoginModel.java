package ModelView;

import Model.Editor;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.concurrent.ExecutionException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class LoginModel implements InterfaceComun<Usuario>{
    DatabaseReference ref=FirebaseDatabase.getInstance().getReference()
            .child("users");
    @Override
    public void registrar(Usuario obj){
        ref=ref.child(obj.getID());
        try {
            if(Editor.exist(ref).get()){
                throw new RuntimeException("El usuario ya existe");
            }else{
                Editor.SetObj(ref, obj);
                throw new RuntimeException("Usuario ha sido registrado efectivamente");
            }
        } catch (InterruptedException | ExecutionException ex) {
        }
    }
    
    @Override
    public void ingresar(Usuario obj,JFrame ventana){
        ref=ref.child(obj.getID());
        try {
            if(Editor.exist(ref).get()){
                if (Editor.ingresar(ref,obj).get()) {
                    JOptionPane.showMessageDialog(ventana, "Iniciando");
                } else {
                    throw new RuntimeException("Contraseña equivocada");
                }
            }else{
                throw new RuntimeException("Usuario no existe");
            }
        } catch (InterruptedException | ExecutionException ex) {
        }
    }
    
}
