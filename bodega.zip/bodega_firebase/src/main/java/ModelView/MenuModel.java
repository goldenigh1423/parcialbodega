package ModelView;

import Model.Editor;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.concurrent.ExecutionException;
import javax.swing.JFrame;

public class MenuModel implements InterfaceComun<Usuario>{
    Producto prod;
    boolean s=false;

    public MenuModel(Producto prod, boolean s) {
        this.prod = prod;
        this.s = s;
    }

    public MenuModel(Producto prod) {
        this.prod = prod;
    }
    DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("users");
    public void eliminar(Usuario obj){
        if(prod==null){
            throw new RuntimeException("No ha seleccionado objeto a eliminar");
        }else{
        obj.getInventario().remove(prod.getID());
        ref=ref.child(obj.getID()).child("inventario").child(prod.getID());
        Editor.eliminar(ref);
        }
    }

    @Override
    public void registrar(Usuario obj) {
        ref=ref.child(obj.getID()).child("inventario").child(prod.getID());
        try {
            if(Editor.exist(ref).get()&&!s){
                throw new RuntimeException("Este producto ya ha sido regitrado");
            }else{
                String sms;
                if (s) {
                    sms="Producto editado efectivamente";
                } else {
                    sms="Producto registrado efectivamente";
                }
                Editor.SetObj(ref, prod);
                obj.putInventario(prod);
                throw new PropioException(sms);
            }
        } catch (InterruptedException | ExecutionException ex) {
        }
    }

    @Override
    public void ingresar(Usuario obj, JFrame ventana) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


}
