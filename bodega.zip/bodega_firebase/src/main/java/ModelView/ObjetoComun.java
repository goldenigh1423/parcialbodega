package ModelView;

public abstract class ObjetoComun {
    protected String Nombre;
    protected String ID;

    public ObjetoComun(String Nombre, String ID) {
        this.Nombre = Nombre;
        this.ID = ID;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public abstract void verificar();
    
}
