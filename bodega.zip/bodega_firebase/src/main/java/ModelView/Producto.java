package ModelView;

public class Producto extends ObjetoComun{
    int precio;
    int costo;
    int cantidad;
    
    public Producto(int precio, int costo, int cantidad, String Nombre, String ID) {
        super(Nombre, ID);
        this.precio = precio;
        this.costo = costo;
        this.cantidad = cantidad;
        verificar();
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    @Override
    public void verificar() {
        if(Nombre.isBlank()||ID.isBlank()){
            throw new RuntimeException("Hay unas casillas que estan sin rellenar, verificalas");
        }else if(costo<0||cantidad<0||precio<0){
            throw new RuntimeException("Hay cantidades menores a cero, verifica");
        }
    }
}
