package ModelView;

public class PropioException extends RuntimeException {

    public PropioException() {
    }

    public PropioException(String message) {
        super(message);
    }

    public PropioException(String message, Throwable cause) {
        super(message, cause);
    }

    public PropioException(Throwable cause) {
        super(cause);
    }
    
}
