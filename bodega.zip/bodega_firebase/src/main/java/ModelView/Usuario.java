package ModelView;

import java.util.HashMap;

public class Usuario extends ObjetoComun{
    protected String contraseña;
    protected HashMap<String,Producto> inventario;

    public Usuario(String contraseña, String Nombre, String ID) {
        super(Nombre, ID);
        this.contraseña = contraseña;
        inventario=new HashMap<>();
        verificar();
    }

    public void setInventario(HashMap<String, Producto> inventario) {
        this.inventario = inventario;
    }

    public HashMap<String, Producto> getInventario() {
        return inventario;
    }

    public void putInventario(Producto obj) {
        this.inventario.put(obj.getID(), obj);
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    @Override
    public void verificar() {
        if(Nombre.isBlank()||ID.isBlank()){
            throw new RuntimeException("Tiene que escribir un usuario");
        }else if(contraseña.isBlank()){
            throw new RuntimeException("Tiene que escribir una contraseña");
        }
    }

    
}
