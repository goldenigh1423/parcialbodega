/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Model;

import com.google.firebase.database.FirebaseDatabase;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

/**
 *
 * @author csant
 */
public class Chat {
    private static ArrayList<Socket> clientes = new ArrayList<>();
    
    public static void main(String[] args) throws IOException {
        conectar.conectar();
        int number=0;
        ServerSocket sv=null;
        Socket sc=null;
        
        int puerto=buscar();
        try {
            InetAddress direccion = InetAddress.getLocalHost();
            System.out.println("Nombre de host de la máquina local: " + direccion.getHostName());
            conectar.setdireccion(FirebaseDatabase.getInstance().getReference().child("direccion"), direccion.getHostAddress());
        } catch (UnknownHostException e) {
        }
        
        conectar.setPuerto(FirebaseDatabase.getInstance().getReference().child("puerto"), puerto);
        DataOutputStream ou;
        try{
            sv=new ServerSocket(puerto);
            System.out.println("Servidor iniciado");
            while(true){
                sc=sv.accept();
                System.out.println("Se ha conctado un cliente");
                ou=new DataOutputStream(sc.getOutputStream());
                ou.writeUTF("Bienvenido");
                clientes.add(sc);
                number++;
                Thread cliente=new Thread(new Cliente(sc));
                cliente.start();
            }
        }catch(IOException e){
        }
    }
    
    public static void enviar(String mensaje,Socket mensajero){
        DataOutputStream ou;
        for(Socket cl:clientes){
            if(cl!=mensajero){
                try {
                    ou=new DataOutputStream(cl.getOutputStream());
                    ou.writeUTF(mensaje);
                } catch (IOException ex) {
                }
            }
        }
    }
        
    private static int buscar() throws IOException{
        int puerto=0;
        for(int i=8000;i<65000;i++){
            try(ServerSocket s=new ServerSocket(i)){
                puerto=i;
                break;
            }
        }
        return puerto;
    }
}
