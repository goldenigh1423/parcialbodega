package Model;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;

public class conectar {
    public static void conectar() throws FileNotFoundException, IOException{
        FileInputStream serviceAccount =new FileInputStream("server.json");

        FirebaseOptions options = new FirebaseOptions.Builder()
            .setCredentials(GoogleCredentials.fromStream(serviceAccount))
            .setDatabaseUrl("https://bodega-5e290-default-rtdb.firebaseio.com")
            .build();

        FirebaseApp.initializeApp(options);
    }
    
    public static CompletableFuture<Integer> getPuerto(DatabaseReference ref){
        CompletableFuture<Integer> puerto=new CompletableFuture<>();
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                if(ds.exists()){
                    puerto.complete(ds.child("puerto").getValue(Integer.class));
                }
            }

            @Override
            public void onCancelled(DatabaseError de) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
            });
        return puerto;
    }
    
    public static CompletableFuture<String> getdireccion (DatabaseReference ref){
        CompletableFuture<String> puerto=new CompletableFuture<>();
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                if(ds.exists()){
                    puerto.complete(ds.child("direccion").getValue(String.class));
                }
            }

            @Override
            public void onCancelled(DatabaseError de) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
            });
        return puerto;
    }
    
    public static void setPuerto(DatabaseReference ref, int obj){
        ref.setValueAsync(obj);
    }
    public static void setdireccion (DatabaseReference ref, String obj){
        ref.setValueAsync(obj);
    }
}
