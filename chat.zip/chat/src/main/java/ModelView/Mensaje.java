package ModelView;

import Model.conectar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.concurrent.ExecutionException;

public class Mensaje{
    private static DatabaseReference ref= FirebaseDatabase.getInstance().getReference();
    public static String getdireccion() throws InterruptedException, ExecutionException{
        return conectar.getdireccion(ref.child("direccion")).get();
    }
    public static Integer getPuerto() throws InterruptedException, ExecutionException{
        return conectar.getPuerto(ref.child("puerto")).get();
    }
}
