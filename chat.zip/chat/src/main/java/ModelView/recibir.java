package ModelView;

import Model.Chat;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import javax.swing.JTextArea;

public class recibir implements Runnable{
    protected Socket cliente;
    JTextArea texto;

    public recibir(Socket cliente, JTextArea texto) {
        this.cliente = cliente;
        this.texto = texto;
    }
    
    @Override
    public void run() {
        DataInputStream in;
        while(true){
            try {
                in=new DataInputStream(cliente.getInputStream());
                String sms=in.readUTF();
                texto.setText(texto.getText()+"\n"+sms);
                Chat.enviar(sms, cliente);
            } catch (IOException ex) {
            }
        }
    }    
}
