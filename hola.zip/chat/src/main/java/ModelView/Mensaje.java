package ModelView;

import Model.conectar;
import Model.Chat;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;

public class Mensaje{
    private static DatabaseReference ref= FirebaseDatabase.getInstance().getReference();
    public static String getdireccion() throws InterruptedException, ExecutionException{
        return conectar.getdireccion(ref).get();
    }
    public static Integer getPuerto() throws InterruptedException, ExecutionException{
        
        return conectar.getPuerto(ref).get();
    }
    public static void enviar(Socket sc, JTextField txt){
        try {
            DataOutputStream ou=new DataOutputStream(sc.getOutputStream());
            ou.writeUTF(txt.getText());
        } catch (IOException ex) {
        }
                
    }
}
