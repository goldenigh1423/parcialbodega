/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventariado;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author csant
 */
public class Conexion {
    public static void conect() {
        try{
            FileInputStream input = new FileInputStream("parcial.json");
            FirebaseOptions options=new FirebaseOptions.Builder()
                    .setCredentials(GoogleCredentials.fromStream(input))
                    .setDatabaseUrl("https://parcial-b8d2f-default-rtdb.firebaseio.com/")
                    .build();
            FirebaseApp.initializeApp(options);
        }catch(FileNotFoundException e) {
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
