/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.inventariado;

import java.io.IOException;

/**
 *
 * @author csant
 */
public class Inventariado {

    public static void main(String[] args) throws IOException {
        Conexion.conect();
        new login().setVisible(true);
    }
}
