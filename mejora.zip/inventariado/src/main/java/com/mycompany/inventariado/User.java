/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventariado;

;

/**
 *
 * @author csant
 */
public class User {
    public String Fecha;
    public String Nombre;

    public User(String Fecha, String Nombre) {
        this.Fecha = Fecha;
        this.Nombre = Nombre;
    }
}
