package com.mycompany.inventariado;

import com.google.cloud.firestore.DocumentReference;
import com.google.firebase.cloud.FirestoreClient;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author csant
 */
public class editor {
    private static final FirebaseDatabase db=FirebaseDatabase.getInstance();
    
    public static boolean registrar(String coleccion, String documento, Map<String,Object> data){
        DatabaseReference ref=FirebaseDatabase.getInstance().getReference();
        Map<String, User> users = new HashMap<>();
        users.put("alanisawesome", new User("June 23, 1912", "Alan Turing"));
        users.put("gracehop", new User("December 9, 1906", "Grace Hopper"));
        ref.child("users").setValueAsync(new User("June 23, 1912", "Alan Turing"));
        return false;
    }
    public static boolean actualizar(String coleccion, String documento, Map<String,Object> data){
        return true;
    }
    public static void leer(String h){
       
    }
}
