/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventariado;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author csant
 */
public class usuario {
    private String nombre;
    private String password;
    

    public usuario(String nombre, String password) {
        this.nombre = nombre;
        this.password = encriptar(password);
    }

    public String getNombre() {
        return nombre;
    }

    public String getPassword() {
        return password;
    }

    private String encriptar(String pas) {
    MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
        byte[] hash = md.digest(pas.getBytes());
        StringBuilder sb = new StringBuilder();

        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }

        return sb.toString();
   }
    
}
