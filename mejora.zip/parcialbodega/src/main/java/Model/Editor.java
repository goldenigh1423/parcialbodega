/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import java.util.concurrent.CompletableFuture;
import javax.swing.JOptionPane;

/**
 *
 * @author ESTUDIANTE
 */
public class Editor {
    public static void editar(DatabaseReference ref,Object obj){
        ref.setValueAsync(obj);
    }
    
    public static CompletableFuture<Boolean> comparar(DatabaseReference ref,String variable,String compa){
        CompletableFuture<Boolean> dato = new CompletableFuture<>();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                dato.complete(compa.equals(ds.child(variable).getValue(String.class)));
            }

            @Override
            public void onCancelled(DatabaseError de) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
        return dato;
    }
    
    public static CompletableFuture<Boolean> exist(DatabaseReference ref){
        CompletableFuture<Boolean> dato = new CompletableFuture<>();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                dato.complete(ds.exists());
            }

            @Override
            public void onCancelled(DatabaseError de) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
            
        });
        return dato;
    }
    
}


