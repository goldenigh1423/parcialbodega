package ModelView;

import Model.Editor;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.concurrent.ExecutionException;
import javax.swing.*;

/**
 *
 * @author ESTUDIANTE
 */
public class ModelLogin {
    DatabaseReference ref=FirebaseDatabase.getInstance().getReference();
    public boolean iniciar(Persona person){
        try {
            if(Editor.exist(ref.child("users").child(person.getId())).get()){
                if(Editor.comparar(ref.child("users").child(person.getId()), "contraseña", person.getContraseña()).get()){
                    JOptionPane.showMessageDialog(null, "Sesion iniciada correctamente");
                    return true;
                }else{
                    JOptionPane.showMessageDialog(null, "Contraseña equivocada");
                    return false;
                }
            }else{
                JOptionPane.showMessageDialog(null, "Usuario no existe");
                return false;
            }
        } catch (InterruptedException | ExecutionException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error");
            return false;
        }
    }
    
    public void registrar(Persona person){
        try {
            if(Editor.exist(ref.child("users").child(person.getId())).get()){
                JOptionPane.showMessageDialog(null, "Este usuario ya existe");
            }
            else{
                Editor.editar(ref.child("users").child(person.getId()), person);
                JOptionPane.showMessageDialog(null, "Usuario ha sido registrado con exito");
            }
        } catch (InterruptedException | ExecutionException ex) {
            JOptionPane.showMessageDialog(null, "Ha sucedido un error");
        }
    }
}
