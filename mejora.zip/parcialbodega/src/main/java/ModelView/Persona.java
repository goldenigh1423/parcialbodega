package ModelView;

public class Persona {
    public String id;
    public String contraseña;

    public Persona(String id, String contraseña) {
        this.id = id;
        this.contraseña = contraseña;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
}
