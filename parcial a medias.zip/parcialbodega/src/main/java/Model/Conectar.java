package Model;

import View.Login;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.io.*;
import javax.swing.JOptionPane;

public class Conectar {
    public static void conect(){
        try {
            FileInputStream serviceAccount =new FileInputStream("parcial.json");
            FirebaseOptions options = new FirebaseOptions.Builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .setDatabaseUrl("https://parcial-b8d2f-default-rtdb.firebaseio.com")
                .build();
            FirebaseApp.initializeApp(options);
            DatabaseReference db=FirebaseDatabase.getInstance().getReference();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "No se ha encontrado el archivo parcial.json");
            System.exit(0);
        } catch (IOException e){
            JOptionPane.showMessageDialog(null, "No se ha encontrado el archivo parcial.json");
            System.exit(0);
        }
    }
}
