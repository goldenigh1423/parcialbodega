/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.http.impl.client.CloseableHttpClient;

/**
 *
 * @author csant
 */
public class NewClass {
    public void metodo(){
        String apiKey = "AIzaSyCXhDAWqaREeWF58p-4q-VxaiGaEUnbYwM"; // Obten tu API Key desde la consola de Firebase
        String email = "caburbanog@unal.edu.co";
        String password = "patatasfritas1423";
        String url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + apiKey;

        String payload = String.format("{\"email\":\"%s\", \"password\":\"%s\", \"returnSecureToken\":true}", email, password);

        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);
            StringEntity entity = new StringEntity(payload);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            try (CloseableHttpResponse response = client.execute(httpPost)) {
                String responseString = EntityUtils.toString(response.getEntity());
                System.err.println("Response: " + responseString);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
