/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Model;

import View.Login;

public class Parcialbodega {

    public static void main(String[] args) {
        Conectar.conect();
        /*Login login=new Login();
        login.setLocationRelativeTo(null);
        login.setVisible(true);  */
        NewClass ne=new NewClass();
        ne.metodo();
             
    }
}
