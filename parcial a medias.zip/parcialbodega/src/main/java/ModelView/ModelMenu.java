package ModelView;

import Model.Editor;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.concurrent.ExecutionException;
import javax.swing.*;
import javax.swing.table.*;

public class ModelMenu {
    DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("users");
    
    public void registrarproducto(String ID,producto obj){
        try {
            ref=ref.child(ID).child("inventario").child(obj.getId());
            if(Editor.exist(ref).get()){
                JOptionPane.showMessageDialog(null, "Este item ya existe");
            }else{
                Editor.editar(ref, obj);
                JOptionPane.showMessageDialog(null, "Item registrado adecuadamente");
            }
        } catch (InterruptedException | ExecutionException e) {
            JOptionPane.showMessageDialog(null, "Hubo un error: "+e.getMessage());
        }
    }
    
    public void rellenar(JTable tabla,String ID){
        ref=ref.child(ID).child("inventario");
        DefaultTableModel model=new DefaultTableModel();
        model.addColumn("Nombre");
        model.addColumn("Precio");
        model.addColumn("ID");
        
        try {
            if(Editor.exist(ref).get()){
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot ds) {
                        for(DataSnapshot child:ds.getChildren()){
                            model.addRow(new Object[]{
                                child.child("nombre").getValue(String.class),
                                child.child("precio").getValue(String.class),
                                child.getKey()
                            });
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError de) {
                        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                    }
                });
            }
        } catch (InterruptedException | ExecutionException e) {
            JOptionPane.showMessageDialog(null, "Hubo un error: "+e.getMessage());
        }
        tabla.setModel(model);
    }
}
