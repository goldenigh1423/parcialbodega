package ModelView;

public class Persona extends registro {

    public String contraseña;

    public Persona(String id, String contraseña) {
        this.id = id;
        this.nombre=id;
        this.contraseña = contraseña;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
}
