package ModelView;

public class producto extends registro{
    protected String precio;

    public producto() {
        this.id=null;
        this.nombre=null;
        this.precio=null;
    }

    public producto(String id, String nombre, String precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
    
    
}
