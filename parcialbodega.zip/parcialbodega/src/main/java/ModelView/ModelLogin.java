/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModelView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author ESTUDIANTE
 */
public class ModelLogin {
    DatabaseReference ref=FirebaseDatabase.getInstance().getReference();
    public void iniciar(JTextField nombre, JTextField contraseña){
        try {
            
        } catch (Exception e) {
        }
    }
    
    public void registrar(JTextField nombre, JTextField contraseña){
        try {
            ref.child("users").child(nombre.getText()).setValueAsync(new Persona(nombre.getText(),contraseña.getText()));
            new JPopupMenu("Hubo un error").setVisible(true);
        } catch (Exception e) {
            new JPopupMenu("Hubo un error").setVisible(true);
            
        }
    }
}
