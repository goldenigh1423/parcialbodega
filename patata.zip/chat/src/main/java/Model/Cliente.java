package Model;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class Cliente implements Runnable{
    protected Socket cliente;

    public Cliente(Socket cliente) {
        this.cliente = cliente;
    }
    
    @Override
    public void run() {    
        DataInputStream in;
        while(true){
            try {
                in=new DataInputStream(cliente.getInputStream());
                String sms=in.readUTF();
                Chat.enviar(sms, cliente);
            } catch (IOException ex) {
            }
        }
    }
    
}
